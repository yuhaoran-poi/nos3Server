// Automatically generated,do not modify.
#include "CmdCode.h"
#include "Protos/AllProto.h"
#include "Net/ProtobufMessage.h"

namespace CommonNetCmd
{
	const TMap<CmdCode, google::protobuf::Message*> ID2Cmd = {
		{CmdCode::PBPacketCmd,new PBPacketCmd()},
		{CmdCode::PBClientLoginReqCmd,new PBClientLoginReqCmd()},
		{CmdCode::Any,new google::protobuf::Any()},
		{CmdCode::PBApplyFriendReqCmd,new PBApplyFriendReqCmd()},
		{CmdCode::PBApplyFriendRspCmd,new PBApplyFriendRspCmd()},
		{CmdCode::PBApplyLoginCityReqCmd,new PBApplyLoginCityReqCmd()},
		{CmdCode::PBApplyLoginCityRspCmd,new PBApplyLoginCityRspCmd()},
		{CmdCode::PBApplyRoomReqCmd,new PBApplyRoomReqCmd()},
		{CmdCode::PBApplyRoomRspCmd,new PBApplyRoomRspCmd()},
		{CmdCode::PBApplyRoomSyncCmd,new PBApplyRoomSyncCmd()},
		{CmdCode::PBChatCmd,new PBChatCmd()},
		{CmdCode::PBChooseWorldChatReqCmd,new PBChooseWorldChatReqCmd()},
		{CmdCode::PBChooseWorldChatRespCmd,new PBChooseWorldChatRespCmd()},
		{CmdCode::PBClientGetUsrSimInfoReqCmd,new PBClientGetUsrSimInfoReqCmd()},
		{CmdCode::PBClientGetUsrSimInfoRspCmd,new PBClientGetUsrSimInfoRspCmd()},
		{CmdCode::PBClientLoginRspCmd,new PBClientLoginRspCmd()},
		{CmdCode::PBCreateRoomReqCmd,new PBCreateRoomReqCmd()},
		{CmdCode::PBCreateRoomRspCmd,new PBCreateRoomRspCmd()},
		{CmdCode::PBDSLoginReqCmd,new PBDSLoginReqCmd()},
		{CmdCode::PBDSLoginRspCmd,new PBDSLoginRspCmd()},
		{CmdCode::PBDealApplyRoomReqCmd,new PBDealApplyRoomReqCmd()},
		{CmdCode::PBDealApplyRoomRspCmd,new PBDealApplyRoomRspCmd()},
		{CmdCode::PBDealApplyRoomSyncCmd,new PBDealApplyRoomSyncCmd()},
		{CmdCode::PBEnterCityReqCmd,new PBEnterCityReqCmd()},
		{CmdCode::PBEnterCityRspCmd,new PBEnterCityRspCmd()},
		{CmdCode::PBEnterDsRoomSyncCmd,new PBEnterDsRoomSyncCmd()},
		{CmdCode::PBEnterRoomReqCmd,new PBEnterRoomReqCmd()},
		{CmdCode::PBEnterRoomRspCmd,new PBEnterRoomRspCmd()},
		{CmdCode::PBEnterRoomSyncCmd,new PBEnterRoomSyncCmd()},
		{CmdCode::PBExitCityReqCmd,new PBExitCityReqCmd()},
		{CmdCode::PBExitCityRspCmd,new PBExitCityRspCmd()},
		{CmdCode::PBExitRoomReqCmd,new PBExitRoomReqCmd()},
		{CmdCode::PBExitRoomRspCmd,new PBExitRoomRspCmd()},
		{CmdCode::PBExitRoomSyncCmd,new PBExitRoomSyncCmd()},
		{CmdCode::PBGetActivityInfoReqCmd,new PBGetActivityInfoReqCmd()},
		{CmdCode::PBGetActivityInfoRspCmd,new PBGetActivityInfoRspCmd()},
		{CmdCode::PBGetFriendInfoReqCmd,new PBGetFriendInfoReqCmd()},
		{CmdCode::PBGetFriendInfoRspCmd,new PBGetFriendInfoRspCmd()},
		{CmdCode::PBGetMailItemReqCmd,new PBGetMailItemReqCmd()},
		{CmdCode::PBGetMailItemRspCmd,new PBGetMailItemRspCmd()},
		{CmdCode::PBGetOpenBoxReqCmd,new PBGetOpenBoxReqCmd()},
		{CmdCode::PBGetOpenBoxRspCmd,new PBGetOpenBoxRspCmd()},
		{CmdCode::PBGetRankInfoReqCmd,new PBGetRankInfoReqCmd()},
		{CmdCode::PBGetRankInfoRspCmd,new PBGetRankInfoRspCmd()},
		{CmdCode::PBGetRoomInfoReqCmd,new PBGetRoomInfoReqCmd()},
		{CmdCode::PBGetRoomInfoRspCmd,new PBGetRoomInfoRspCmd()},
		{CmdCode::PBGetTradeBankInfoReqCmd,new PBGetTradeBankInfoReqCmd()},
		{CmdCode::PBGetTradeBankInfoRspCmd,new PBGetTradeBankInfoRspCmd()},
		{CmdCode::PBGuildAcceptTaskReqCmd,new PBGuildAcceptTaskReqCmd()},
		{CmdCode::PBGuildAcceptTaskRspCmd,new PBGuildAcceptTaskRspCmd()},
		{CmdCode::PBGuildAddDutyReqCmd,new PBGuildAddDutyReqCmd()},
		{CmdCode::PBGuildAddDutyRspCmd,new PBGuildAddDutyRspCmd()},
		{CmdCode::PBGuildAddItems2BagCmd,new PBGuildAddItems2BagCmd()},
		{CmdCode::PBGuildAddItemsCmd,new PBGuildAddItemsCmd()},
		{CmdCode::PBGuildAnswerApplyJoinGuildReqCmd,new PBGuildAnswerApplyJoinGuildReqCmd()},
		{CmdCode::PBGuildAnswerApplyJoinGuildRspCmd,new PBGuildAnswerApplyJoinGuildRspCmd()},
		{CmdCode::PBGuildAnswerInviteJoinGuildReqCmd,new PBGuildAnswerInviteJoinGuildReqCmd()},
		{CmdCode::PBGuildApplyJoinGuildReqCmd,new PBGuildApplyJoinGuildReqCmd()},
		{CmdCode::PBGuildApplyJoinGuildRspCmd,new PBGuildApplyJoinGuildRspCmd()},
		{CmdCode::PBGuildBoardcastGuildDismissCmd,new PBGuildBoardcastGuildDismissCmd()},
		{CmdCode::PBGuildBoardcastPlayerApplyCmd,new PBGuildBoardcastPlayerApplyCmd()},
		{CmdCode::PBGuildBoardcastPlayerExitCmd,new PBGuildBoardcastPlayerExitCmd()},
		{CmdCode::PBGuildBoardcastPlayerJoinCmd,new PBGuildBoardcastPlayerJoinCmd()},
		{CmdCode::PBGuildBuyRecommentReqCmd,new PBGuildBuyRecommentReqCmd()},
		{CmdCode::PBGuildBuyRecommentRspCmd,new PBGuildBuyRecommentRspCmd()},
		{CmdCode::PBGuildCreateGuildReqCmd,new PBGuildCreateGuildReqCmd()},
		{CmdCode::PBGuildCreateGuildRspCmd,new PBGuildCreateGuildRspCmd()},
		{CmdCode::PBGuildDayMissionAwardReqCmd,new PBGuildDayMissionAwardReqCmd()},
		{CmdCode::PBGuildDayMissionAwardRspCmd,new PBGuildDayMissionAwardRspCmd()},
		{CmdCode::PBGuildDelDutyReqCmd,new PBGuildDelDutyReqCmd()},
		{CmdCode::PBGuildDelDutyRspCmd,new PBGuildDelDutyRspCmd()},
		{CmdCode::PBGuildDelItemsCmd,new PBGuildDelItemsCmd()},
		{CmdCode::PBGuildDemiseReqCmd,new PBGuildDemiseReqCmd()},
		{CmdCode::PBGuildDemiseRspCmd,new PBGuildDemiseRspCmd()},
		{CmdCode::PBGuildDismissReqCmd,new PBGuildDismissReqCmd()},
		{CmdCode::PBGuildDismissRspCmd,new PBGuildDismissRspCmd()},
		{CmdCode::PBGuildDkpChangeReqCmd,new PBGuildDkpChangeReqCmd()},
		{CmdCode::PBGuildDkpChangeRspCmd,new PBGuildDkpChangeRspCmd()},
		{CmdCode::PBGuildDonateReqCmd,new PBGuildDonateReqCmd()},
		{CmdCode::PBGuildDonateRspCmd,new PBGuildDonateRspCmd()},
		{CmdCode::PBGuildExchangeItemReqCmd,new PBGuildExchangeItemReqCmd()},
		{CmdCode::PBGuildExchangeItemRspCmd,new PBGuildExchangeItemRspCmd()},
		{CmdCode::PBGuildExpelQuitReqCmd,new PBGuildExpelQuitReqCmd()},
		{CmdCode::PBGuildExpelQuitRspCmd,new PBGuildExpelQuitRspCmd()},
		{CmdCode::PBGuildFullDataUpdateCmd,new PBGuildFullDataUpdateCmd()},
		{CmdCode::PBGuildGetApplyListReqCmd,new PBGuildGetApplyListReqCmd()},
		{CmdCode::PBGuildGetApplyListRspCmd,new PBGuildGetApplyListRspCmd()},
		{CmdCode::PBGuildGetGuildListReqCmd,new PBGuildGetGuildListReqCmd()},
		{CmdCode::PBGuildGetGuildListRspCmd,new PBGuildGetGuildListRspCmd()},
		{CmdCode::PBGuildGetMembersReqCmd,new PBGuildGetMembersReqCmd()},
		{CmdCode::PBGuildGetMembersRspCmd,new PBGuildGetMembersRspCmd()},
		{CmdCode::PBGuildGetSalaryReqCmd,new PBGuildGetSalaryReqCmd()},
		{CmdCode::PBGuildGetSalaryRspCmd,new PBGuildGetSalaryRspCmd()},
		{CmdCode::PBGuildGetTaskRewardReqCmd,new PBGuildGetTaskRewardReqCmd()},
		{CmdCode::PBGuildGetTaskRewardRspCmd,new PBGuildGetTaskRewardRspCmd()},
		{CmdCode::PBGuildGrantReqCmd,new PBGuildGrantReqCmd()},
		{CmdCode::PBGuildGrantRspCmd,new PBGuildGrantRspCmd()},
		{CmdCode::PBGuildInviteJoinGuildReqCmd,new PBGuildInviteJoinGuildReqCmd()},
		{CmdCode::PBGuildInviteJoinGuildRspCmd,new PBGuildInviteJoinGuildRspCmd()},
		{CmdCode::PBGuildModifyAnnouncementReqCmd,new PBGuildModifyAnnouncementReqCmd()},
		{CmdCode::PBGuildModifyAnnouncementRspCmd,new PBGuildModifyAnnouncementRspCmd()},
		{CmdCode::PBGuildModifyDutyLevelReqCmd,new PBGuildModifyDutyLevelReqCmd()},
		{CmdCode::PBGuildModifyDutyLevelRspCmd,new PBGuildModifyDutyLevelRspCmd()},
		{CmdCode::PBGuildModifyDutyNameReqCmd,new PBGuildModifyDutyNameReqCmd()},
		{CmdCode::PBGuildModifyDutyNameRspCmd,new PBGuildModifyDutyNameRspCmd()},
		{CmdCode::PBGuildModifyDutyRightReqCmd,new PBGuildModifyDutyRightReqCmd()},
		{CmdCode::PBGuildModifyDutyRightRspCmd,new PBGuildModifyDutyRightRspCmd()},
		{CmdCode::PBGuildModifyGuildNameReqCmd,new PBGuildModifyGuildNameReqCmd()},
		{CmdCode::PBGuildModifyGuildNameRspCmd,new PBGuildModifyGuildNameRspCmd()},
		{CmdCode::PBGuildModifyHeadIconReqCmd,new PBGuildModifyHeadIconReqCmd()},
		{CmdCode::PBGuildModifyHeadIconRspCmd,new PBGuildModifyHeadIconRspCmd()},
		{CmdCode::PBGuildPlayerSetGuildInfoCmd,new PBGuildPlayerSetGuildInfoCmd()},
		{CmdCode::PBGuildQuitReqCmd,new PBGuildQuitReqCmd()},
		{CmdCode::PBGuildQuitRspCmd,new PBGuildQuitRspCmd()},
		{CmdCode::PBGuildRecordListReqCmd,new PBGuildRecordListReqCmd()},
		{CmdCode::PBGuildRecordListRspCmd,new PBGuildRecordListRspCmd()},
		{CmdCode::PBGuildSearchGuildReqCmd,new PBGuildSearchGuildReqCmd()},
		{CmdCode::PBGuildSearchGuildRspCmd,new PBGuildSearchGuildRspCmd()},
		{CmdCode::PBGuildSendSpoilsReqCmd,new PBGuildSendSpoilsReqCmd()},
		{CmdCode::PBGuildSendSpoilsRspCmd,new PBGuildSendSpoilsRspCmd()},
		{CmdCode::PBGuildSetHeadReqCmd,new PBGuildSetHeadReqCmd()},
		{CmdCode::PBGuildSetHeadRspCmd,new PBGuildSetHeadRspCmd()},
		{CmdCode::PBGuildSetSpoilsMgrReqCmd,new PBGuildSetSpoilsMgrReqCmd()},
		{CmdCode::PBGuildSetSpoilsMgrRspCmd,new PBGuildSetSpoilsMgrRspCmd()},
		{CmdCode::PBGuildShopBuyItemReqCmd,new PBGuildShopBuyItemReqCmd()},
		{CmdCode::PBGuildShopBuyItemRspCmd,new PBGuildShopBuyItemRspCmd()},
		{CmdCode::PBGuildThawReqCmd,new PBGuildThawReqCmd()},
		{CmdCode::PBGuildThawRspCmd,new PBGuildThawRspCmd()},
		{CmdCode::PBGuildUpdateDutyListCmd,new PBGuildUpdateDutyListCmd()},
		{CmdCode::PBGuildUpdateGuildBagCmd,new PBGuildUpdateGuildBagCmd()},
		{CmdCode::PBGuildUpdateGuildInfoRspCmd,new PBGuildUpdateGuildInfoRspCmd()},
		{CmdCode::PBGuildUpdateGuildLevelCmd,new PBGuildUpdateGuildLevelCmd()},
		{CmdCode::PBGuildUpdateGuildRecordInfoCmd,new PBGuildUpdateGuildRecordInfoCmd()},
		{CmdCode::PBGuildUpdateGuildUserDataCmd,new PBGuildUpdateGuildUserDataCmd()},
		{CmdCode::PBGuildUpdateMeApplyGuildListCmd,new PBGuildUpdateMeApplyGuildListCmd()},
		{CmdCode::PBGuildUpdateMeInviteGuildListCmd,new PBGuildUpdateMeInviteGuildListCmd()},
		{CmdCode::PBGuildUpdateShopInfoCmd,new PBGuildUpdateShopInfoCmd()},
		{CmdCode::PBGuildUpdateShopReqCmd,new PBGuildUpdateShopReqCmd()},
		{CmdCode::PBGuildUpdateTaskInfoRspCmd,new PBGuildUpdateTaskInfoRspCmd()},
		{CmdCode::PBGuildUpdateTaskListRspCmd,new PBGuildUpdateTaskListRspCmd()},
		{CmdCode::PBGuildUpgradeMemberMaxcountReqCmd,new PBGuildUpgradeMemberMaxcountReqCmd()},
		{CmdCode::PBGuildUpgradeMemberMaxcountRspCmd,new PBGuildUpgradeMemberMaxcountRspCmd()},
		{CmdCode::PBGuildUpgradeReqCmd,new PBGuildUpgradeReqCmd()},
		{CmdCode::PBGuildUpgradeRspCmd,new PBGuildUpgradeRspCmd()},
		{CmdCode::PBKickRoomReqCmd,new PBKickRoomReqCmd()},
		{CmdCode::PBKickRoomRspCmd,new PBKickRoomRspCmd()},
		{CmdCode::PBKickRoomSyncCmd,new PBKickRoomSyncCmd()},
		{CmdCode::PBModRoomReqCmd,new PBModRoomReqCmd()},
		{CmdCode::PBModRoomRspCmd,new PBModRoomRspCmd()},
		{CmdCode::PBNotifyWorldChatCmd,new PBNotifyWorldChatCmd()},
		{CmdCode::PBOpenGuildJuanZengCmd,new PBOpenGuildJuanZengCmd()},
		{CmdCode::PBPingCmd,new PBPingCmd()},
		{CmdCode::PBPongCmd,new PBPongCmd()},
		{CmdCode::PBReadyRoomReqCmd,new PBReadyRoomReqCmd()},
		{CmdCode::PBReadyRoomRspCmd,new PBReadyRoomRspCmd()},
		{CmdCode::PBReadyRoomSyncCmd,new PBReadyRoomSyncCmd()},
		{CmdCode::PBRoomInfoSyncCmd,new PBRoomInfoSyncCmd()},
		{CmdCode::PBSearchRoomReqCmd,new PBSearchRoomReqCmd()},
		{CmdCode::PBSearchRoomRspCmd,new PBSearchRoomRspCmd()},
		{CmdCode::PBSetGuildJoinConditionReqCmd,new PBSetGuildJoinConditionReqCmd()},
		{CmdCode::PBSetGuildJoinConditionRspCmd,new PBSetGuildJoinConditionRspCmd()},
		{CmdCode::PBSetGuildStatusCmd,new PBSetGuildStatusCmd()},
		{CmdCode::PBStartGameRoomReqCmd,new PBStartGameRoomReqCmd()},
		{CmdCode::PBStartGameRoomRspCmd,new PBStartGameRoomRspCmd()},
		{CmdCode::PBSyncWorldChatCmd,new PBSyncWorldChatCmd()},
		{CmdCode::PBTeamCreateReqCmd,new PBTeamCreateReqCmd()},
		{CmdCode::PBTeamCreateRspCmd,new PBTeamCreateRspCmd()},
		{CmdCode::PBTeamExitReqCmd,new PBTeamExitReqCmd()},
		{CmdCode::PBTeamExitRspCmd,new PBTeamExitRspCmd()},
		{CmdCode::PBTeamInfoReqCmd,new PBTeamInfoReqCmd()},
		{CmdCode::PBTeamInfoRspCmd,new PBTeamInfoRspCmd()},
		{CmdCode::PBTeamJoinReqCmd,new PBTeamJoinReqCmd()},
		{CmdCode::PBTeamJoinRspCmd,new PBTeamJoinRspCmd()},
		{CmdCode::PBTeamKickoutReqCmd,new PBTeamKickoutReqCmd()},
		{CmdCode::PBTeamKickoutRspCmd,new PBTeamKickoutRspCmd()},
		{CmdCode::PBTeamStatusCmd,new PBTeamStatusCmd()},
		{CmdCode::PBUpdateCityReqCmd,new PBUpdateCityReqCmd()},
		{CmdCode::PBUpdateCityRspCmd,new PBUpdateCityRspCmd()},
		{CmdCode::PBUpdateMissionClientSyncCmd,new PBUpdateMissionClientSyncCmd()},
		{CmdCode::PBUpdateMissionSeverSyncCmd,new PBUpdateMissionSeverSyncCmd()},

	};
    TMap<CmdCode,TSubclassOf<UProtobufMessage>> ID2Proto = {};
    std::map<std::string,CmdCode> Cmd2ID = {};
	CmdCode GetCmdCodeByName(const std::string& MsgName)
	{
		if(Cmd2ID.size() == 0)
		{
			for(const auto& Iter : ID2Cmd)
			{
				Cmd2ID[Iter.Value->GetTypeName()] = Iter.Key;
			}
		}
		const auto Iter = Cmd2ID.find(MsgName);
		if(Iter!=Cmd2ID.end())
		{
			return Iter->second;
		}
		return CmdCode::None;
	}

	CmdCode GetCmdCode(const google::protobuf::Message& Msg)
	{
		return GetCmdCodeByName(Msg.GetTypeName());
	}

    CmdCode GetProtoMsgType(const UProtobufMessage* Msg)
    {
	    if (Msg)
	    {
		    FString ClassName = Msg->GetName();
	    	ClassName = UProtobufMessage::GetClassNameWithoutSuffix(ClassName);
	    	const ANSICHAR* AnsiStr = TCHAR_TO_UTF8(*ClassName);
	    	const std::string Str(AnsiStr);
	    	return GetCmdCodeByName(Str); 
	    	
	    }
	    return CmdCode::None;
    }

	TSubclassOf<UProtobufMessage> GetProtoByCmd(CmdCode Cmd)
	{
		if (!ID2Proto.Contains(Cmd))
		  return nullptr;
		return ID2Proto[Cmd];
	}
 
}
